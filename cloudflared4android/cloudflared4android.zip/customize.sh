#!/system/bin/sh
# customize.sh - Magisk 安装脚本
# 由 update-binary 通过 install_module -> util_functions.sh 加载执行
# 可用变量: $ARCH $API $TMPDIR $ZIPFILE $MODPATH
# 可用函数: ui_print abort set_perm set_perm_recursive

ui_print " "
ui_print "*******************************"
ui_print "*      Cloudflare Tunnel      *"
ui_print "*         Magisk 模块         *"
ui_print "*******************************"
ui_print "* 操作按钮: 启动 / 停止       *"
ui_print "* WebUI: 编辑 Token / 看状态  *"
ui_print "* 配置: 模块目录内 token.txt  *"
ui_print "*******************************"
ui_print " "

# ============ 架构检测与二进制安装 ============
ui_print "- 检测设备架构..."
case "$ARCH" in
    arm64)
        BIN_SRC="$MODPATH/binary/cloudflared-termux-arm64"
        BIN_DROP="$MODPATH/binary/cloudflared-termux-arm"
        ;;
    arm)
        BIN_SRC="$MODPATH/binary/cloudflared-termux-arm"
        BIN_DROP="$MODPATH/binary/cloudflared-termux-arm64"
        ;;
    *)
        abort "! 不支持的架构: $ARCH（仅支持 arm / arm64）"
        ;;
esac

if [ ! -f "$BIN_SRC" ]; then
    abort "! 安装包内缺少 $ARCH 架构的 cloudflared 二进制文件"
fi

ui_print "- 安装 cloudflared ($ARCH)..."
mkdir -p "$MODPATH/system/bin"
mv -f "$BIN_SRC" "$MODPATH/system/bin/cloudflared"
rm -f "$BIN_DROP"
rmdir "$MODPATH/binary" 2>/dev/null || true
ui_print "  ✓ 已安装 ($(wc -c < "$MODPATH/system/bin/cloudflared") 字节)"

# ============ 保留用户数据 ============
# token.txt / state 是用户数据，edge.cache 是上次解析成功的边缘节点；升级时都从旧目录搬过来
OLD_MODDIR="/data/adb/modules/${MODID:-cloudflared4android}"

ui_print "- 迁移用户数据..."
for _f in token.txt state edge.cache; do
    if [ ! -f "$MODPATH/$_f" ] && [ -f "$OLD_MODDIR/$_f" ]; then
        cp -af "$OLD_MODDIR/$_f" "$MODPATH/$_f"
        ui_print "  ✓ 已保留 $_f"
    fi
done

# 首次安装时生成 token.txt 模板
if [ ! -f "$MODPATH/token.txt" ]; then
    cat > "$MODPATH/token.txt" << 'EOF'
# ============================================
# Cloudflare Tunnel Token 列表
# ============================================
# 一行一个 Token，多个 Token 会同时启动多个隧道。
# 空行和以 # 开头的行会被忽略。
#
# 获取方式:
#   https://one.dash.cloudflare.com
#   → Networks → Tunnels → 创建隧道 → 复制 Token
#
# 保存后点击模块的「操作」按钮即可启动。
# 日志目录: 模块目录下的 logs/
# ============================================

# 示例（删除行首的 # 并替换为真实 Token）:
# eyJhIjoiYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoifQ...
EOF
    ui_print "  → 已创建 token.txt 模板，请填写 Token"
fi

# ============ 权限 ============
ui_print "- 设置文件权限..."
# 注意：不要为 webroot/ 单独设权限或 SELinux 上下文。
# KernelSU 会自行处理该目录，官方文档明确要求不要手动改；
# 这里的递归调用只是 Magisk 的标准默认值，不涉及上下文变更。
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/system/bin/cloudflared" 0 0 0755
set_perm "$MODPATH/cloudflared.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/token.txt" 0 0 0600
ui_print "  ✓ 权限设置完成"

# ============ 完成 ============
ui_print " "
ui_print "*******************************"
ui_print "*         安装成功！          *"
ui_print "*******************************"
ui_print "* 1. 编辑模块目录的 token.txt *"
ui_print "* 2. 点击模块「操作」按钮启动 *"
ui_print "* 3. 再点一次即可停止         *"
ui_print "*******************************"
ui_print "* 也可在 WebUI 里直接编辑 Token*"
ui_print "* 重启后自动恢复上次状态      *"
ui_print "*******************************"
ui_print " "
