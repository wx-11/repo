#!/system/bin/sh
# action.sh - 模块「操作」按钮入口
# 点击一次启动隧道，再次点击停止

MODDIR=${0%/*}

exec sh "$MODDIR/cloudflared.sh" toggle
