#!/system/bin/sh
# cloudflared.sh - Cloudflare Tunnel (Token 多实例) 控制脚本
#
# 用法:
#   cloudflared.sh start     启动 token.txt 中的全部隧道
#   cloudflared.sh stop      停止全部隧道
#   cloudflared.sh restart   重启全部隧道
#   cloudflared.sh toggle    在 启动/停止 之间切换（模块操作按钮调用）
#   cloudflared.sh status    打印当前状态
#   cloudflared.sh boot      开机时按上次状态恢复
#   cloudflared.sh refresh   仅刷新模块描述中的运行状态
#
# 约束: 必须兼容 POSIX sh（Magisk / KernelSU 的 busybox ash）

# ============ 路径常量 ============
# 所有数据都存放在模块目录内，不使用外部存储
case "$0" in
    */*) MODDIR=${0%/*} ;;
    *)   MODDIR=$(pwd) ;;
esac

MODULE_ID="cloudflared4android"
TOKEN_FILE="$MODDIR/token.txt"
STATE_FILE="$MODDIR/state"
RUN_DIR="$MODDIR/run"
LOG_DIR="$MODDIR/logs"

CFD_BIN="$MODDIR/system/bin/cloudflared"
MODPROP="$MODDIR/module.prop"
PROC_PATTERN="$MODDIR/system/bin/cloudflared tunnel"

LOG_LEVEL="info"
BASE_DESC="Cloudflare Tunnel 多实例"

# ============ 基础工具 ============
log() {
    echo "$1"
}

ensure_dirs() {
    mkdir -p "$RUN_DIR" "$LOG_DIR" 2>/dev/null || true
}

# 输出 token 文件路径；不存在时返回 1
resolve_token_file() {
    if [ -s "$TOKEN_FILE" ]; then
        echo "$TOKEN_FILE"
        return 0
    fi
    return 1
}

# 输出有效 Token：去 CR、去首尾空白、跳过空行与 # 注释
list_tokens() {
    tr -d '\r' < "$1" \
        | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
        | grep -v '^#' \
        | grep -v '^$'
}

token_count() {
    _tf=$(resolve_token_file) || { echo 0; return 0; }
    list_tokens "$_tf" | wc -l | tr -d ' '
}

# 仍在运行的隧道数量（顺带清理失效的 pid 文件）
running_count() {
    _n=0
    for _f in "$RUN_DIR"/*.pid; do
        [ -f "$_f" ] || continue
        _p=$(cat "$_f" 2>/dev/null)
        if [ -n "$_p" ] && kill -0 "$_p" 2>/dev/null; then
            _n=$((_n + 1))
        else
            rm -f "$_f"
        fi
    done
    echo "$_n"
}

# ============ 模块描述（运行状态展示） ============
# 写入策略：module.prop 覆盖所有管理器；KernelSU/APatch 额外走官方 override 机制
write_description() {
    _text="$1"

    if [ -f "$MODPROP" ]; then
        _tmp="$MODPROP.tmp.$$"
        if grep -v '^description=' "$MODPROP" > "$_tmp" 2>/dev/null; then
            printf 'description=%s\n' "$_text" >> "$_tmp"
            mv -f "$_tmp" "$MODPROP"
        fi
        rm -f "$_tmp" 2>/dev/null
    fi

    if command -v ksud >/dev/null 2>&1; then
        KSU_MODULE="$MODULE_ID" ksud module config set override.description "$_text" >/dev/null 2>&1 || true
    fi
}

refresh_description() {
    if ! resolve_token_file >/dev/null 2>&1; then
        write_description "$BASE_DESC | ⚠️ 未找到 token.txt"
        return 0
    fi

    _total=$(token_count)
    if [ "$_total" -eq 0 ]; then
        write_description "$BASE_DESC | ⚠️ token.txt 无有效 Token"
        return 0
    fi

    _run=$(running_count)
    if [ "$_run" -gt 0 ]; then
        write_description "$BASE_DESC | 🟢 运行中 ($_run/$_total)"
    else
        write_description "$BASE_DESC | ⚪ 已停止"
    fi
}

# ============ 单实例启停 ============
start_one() {
    _idx="$1"
    _token="$2"
    _pidfile="$RUN_DIR/$_idx.pid"
    _logfile="$LOG_DIR/tunnel-$_idx.log"

    _old=$(cat "$_pidfile" 2>/dev/null)
    if [ -n "$_old" ] && kill -0 "$_old" 2>/dev/null; then
        log "  隧道 #$_idx 已在运行 (PID: $_old)"
        return 0
    fi

    HOME="$MODDIR" TMPDIR="$MODDIR" TUNNEL_EDGE_IP_VERSION=4 \
        nohup "$CFD_BIN" tunnel \
        --no-autoupdate \
        --edge-ip-version 4 \
        --loglevel "$LOG_LEVEL" \
        run --token "$_token" \
        >> "$_logfile" 2>&1 &

    _pid=$!
    echo "$_pid" > "$_pidfile"
    sleep 1

    if kill -0 "$_pid" 2>/dev/null; then
        renice -5 "$_pid" >/dev/null 2>&1 || true
        log "  ✓ 隧道 #$_idx 已启动 (PID: $_pid)"
        return 0
    fi

    rm -f "$_pidfile"
    log "  ✗ 隧道 #$_idx 启动失败，详见 $LOG_DIR/tunnel-$_idx.log"
    return 1
}

stop_one() {
    _idx="$1"
    _pidfile="$RUN_DIR/$_idx.pid"
    _pid=$(cat "$_pidfile" 2>/dev/null)

    if [ -z "$_pid" ] || ! kill -0 "$_pid" 2>/dev/null; then
        rm -f "$_pidfile"
        return 0
    fi

    kill -TERM "$_pid" 2>/dev/null
    _w=0
    while [ "$_w" -lt 5 ] && kill -0 "$_pid" 2>/dev/null; do
        sleep 1
        _w=$((_w + 1))
    done

    if kill -0 "$_pid" 2>/dev/null; then
        kill -9 "$_pid" 2>/dev/null
        sleep 1
    fi

    rm -f "$_pidfile"
    return 0
}

# 兜底清理：杀掉没有 pid 记录的残留进程
cleanup_orphans() {
    pkill -TERM -f "$PROC_PATTERN" 2>/dev/null || true
    sleep 1
    pkill -KILL -f "$PROC_PATTERN" 2>/dev/null || true
    rm -f "$RUN_DIR"/*.pid 2>/dev/null || true
}

# ============ 命令实现 ============
cmd_start() {
    ensure_dirs

    if [ ! -w "$MODDIR" ]; then
        log "✗ 模块目录不可写: $MODDIR"
        return 1
    fi

    if [ ! -x "$CFD_BIN" ]; then
        log "✗ 找不到可执行文件: $CFD_BIN"
        return 1
    fi

    # 进程还在跑但 pid 记录已丢失（例如模块刚升级），先清理干净再启动
    if [ "$(running_count)" -eq 0 ]; then
        cleanup_orphans
    fi

    _tf=$(resolve_token_file) || {
        log "✗ 未找到 token.txt"
        log "  请编辑: $TOKEN_FILE"
        echo "disabled" > "$STATE_FILE" 2>/dev/null || true
        refresh_description
        return 1
    }

    _count=$(token_count)
    if [ "$_count" -eq 0 ]; then
        log "✗ $_tf 中没有有效 Token（每行一个，# 开头为注释）"
        echo "disabled" > "$STATE_FILE" 2>/dev/null || true
        refresh_description
        return 1
    fi

    log "Token 来源: $_tf"
    log "待启动隧道: $_count 个"

    _list="$RUN_DIR/tokens.list"
    list_tokens "$_tf" > "$_list"

    _i=0
    _ok=0
    while IFS= read -r _tk; do
        _i=$((_i + 1))
        start_one "$_i" "$_tk" && _ok=$((_ok + 1))
    done < "$_list"
    rm -f "$_list"

    if [ "$_ok" -gt 0 ]; then
        echo "enabled" > "$STATE_FILE" 2>/dev/null || true
        log "启动完成: $_ok/$_count 个隧道运行中"
    else
        echo "disabled" > "$STATE_FILE" 2>/dev/null || true
        log "启动失败: 0/$_count"
    fi

    refresh_description
    [ "$_ok" -gt 0 ]
}

cmd_stop() {
    ensure_dirs
    log "停止全部隧道..."

    for _f in "$RUN_DIR"/*.pid; do
        [ -f "$_f" ] || continue
        _idx=$(basename "$_f" .pid)
        stop_one "$_idx"
        log "  ✓ 隧道 #$_idx 已停止"
    done

    cleanup_orphans

    echo "disabled" > "$STATE_FILE" 2>/dev/null || true
    log "已全部停止"
    refresh_description
    return 0
}

cmd_status() {
    _tf=$(resolve_token_file 2>/dev/null)
    _total=$(token_count)
    _run=$(running_count)

    log "模块目录   : $MODDIR"
    log "Token 文件 : ${_tf:-未找到}"
    log "已配置隧道 : $_total"
    log "运行中隧道 : $_run"
    log "开机自启   : $(cat "$STATE_FILE" 2>/dev/null || echo unknown)"

    for _f in "$RUN_DIR"/*.pid; do
        [ -f "$_f" ] || continue
        _idx=$(basename "$_f" .pid)
        _p=$(cat "$_f" 2>/dev/null)
        if [ -n "$_p" ] && kill -0 "$_p" 2>/dev/null; then
            log "  #$_idx 运行中 (PID: $_p)"
        fi
    done

    log "日志目录   : $LOG_DIR"
}

cmd_toggle() {
    ensure_dirs

    if [ "$(running_count)" -gt 0 ]; then
        log "当前状态: 运行中，执行停止"
        cmd_stop
    else
        log "当前状态: 已停止，执行启动"
        cmd_start
    fi
}

cmd_boot() {
    if [ "$(cat "$STATE_FILE" 2>/dev/null)" = "enabled" ]; then
        cmd_start
    else
        refresh_description
    fi
}

# ============ 入口 ============
case "$1" in
    start)   cmd_start ;;
    stop)    cmd_stop ;;
    restart) cmd_stop; cmd_start ;;
    toggle)  cmd_toggle ;;
    status)  cmd_status ;;
    boot)    cmd_boot ;;
    refresh) refresh_description ;;
    *)
        echo "用法: $0 {start|stop|restart|toggle|status|boot|refresh}"
        exit 1
        ;;
esac
