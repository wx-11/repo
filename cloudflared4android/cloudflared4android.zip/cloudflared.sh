#!/system/bin/sh
# cloudflared.sh - Cloudflare Tunnel (Token 多实例) 控制脚本
#
# 用法:
#   cloudflared.sh start     启动 token.txt 中的全部隧道
#   cloudflared.sh stop      停止全部隧道
#   cloudflared.sh restart   重启全部隧道
#   cloudflared.sh toggle    在 启动/停止 之间切换（模块操作按钮调用）
#   cloudflared.sh status    打印当前状态
#   cloudflared.sh boot      开机时按上次状态恢复
#   cloudflared.sh refresh   仅刷新模块描述中的运行状态
#
# 约束: 必须兼容 POSIX sh（Magisk / KernelSU 的 busybox ash）

# ============ 路径常量 ============
# 所有数据都存放在模块目录内，不使用外部存储
case "$0" in
    */*) MODDIR=${0%/*} ;;
    *)   MODDIR=$(pwd) ;;
esac

MODULE_ID="cloudflared4android"
TOKEN_FILE="$MODDIR/token.txt"
STATE_FILE="$MODDIR/state"
RUN_DIR="$MODDIR/run"
LOG_DIR="$MODDIR/logs"

CFD_BIN="$MODDIR/system/bin/cloudflared"
MODPROP="$MODDIR/module.prop"
PROC_PATTERN="$MODDIR/system/bin/cloudflared tunnel"

LOG_LEVEL="info"
BASE_DESC="Cloudflare Tunnel 多实例"

# ============ 边缘节点直连 ============
# cloudflared 默认先做一次 SRV 查询（_v2-origintunneld._tcp.argotunnel.com）找边缘节点，
# 这一步在开着 VPN 时常被截成 lame referral，隧道起不来。
# 而 SRV 指向的就是下面两个域名的 7844 端口。模块自己解析出 IP 后用 --edge 直接喂给
# cloudflared，它就完全跳过 SRV 查询（源码 supervisor.go：len(EdgeAddrs)>0 即走 StaticEdge）。
EDGE_HOSTS="region1.v2.argotunnel.com region2.v2.argotunnel.com"
EDGE_PORT="7844"
EDGE_DNS="223.5.5.5 119.29.29.29"          # 解析用的 DNS，按顺序尝试
EDGE_CACHE="$MODDIR/edge.cache"            # 上次成功解析的结果，解析失败时兜底
# 内置兜底：2026-09-21 从 1.1.1.1 / 223.5.5.5 / 119.29.29.29 取得的一致结果。
# 边缘 IP 段长期稳定在 198.41.192.0/24 与 198.41.200.0/24，但具体主机会变，
# 这份列表只在解析与缓存都失败时才用。
EDGE_BUILTIN="198.41.192.227 198.41.192.47 198.41.192.67 198.41.192.27 198.41.192.7 198.41.192.37 198.41.192.57 198.41.192.107 198.41.192.167 198.41.192.77 198.41.200.113 198.41.200.13 198.41.200.23 198.41.200.33 198.41.200.43 198.41.200.53 198.41.200.63 198.41.200.73 198.41.200.193 198.41.200.233"


# ============ 基础工具 ============
log() {
    echo "$1"
}

ensure_dirs() {
    mkdir -p "$RUN_DIR" "$LOG_DIR" 2>/dev/null || true
}

# 短暂等待：busybox / toybox 都支持小数秒，个别精简版不支持时退回 1 秒
nap() {
    sleep 0.2 2>/dev/null || sleep 1
}

# 给定的 pid 里是否还有活着的
alive_any() {
    for _ap in "$@"; do
        kill -0 "$_ap" 2>/dev/null && return 0
    done
    return 1
}

# 输出 token 文件路径；不存在时返回 1
resolve_token_file() {
    if [ -s "$TOKEN_FILE" ]; then
        echo "$TOKEN_FILE"
        return 0
    fi
    return 1
}

# 输出有效 Token：去 CR、去首尾空白、跳过空行与 # 注释
list_tokens() {
    tr -d '\r' < "$1" \
        | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
        | grep -v '^#' \
        | grep -v '^$'
}

token_count() {
    _tf=$(resolve_token_file) || { echo 0; return 0; }
    list_tokens "$_tf" | wc -l | tr -d ' '
}

# 仍在运行的隧道数量（顺带清理失效的 pid 文件）
running_count() {
    _n=0
    for _f in "$RUN_DIR"/*.pid; do
        [ -f "$_f" ] || continue
        _p=$(cat "$_f" 2>/dev/null)
        if [ -n "$_p" ] && kill -0 "$_p" 2>/dev/null; then
            _n=$((_n + 1))
        else
            rm -f "$_f"
        fi
    done
    echo "$_n"
}

# ============ 边缘节点解析 ============
# 找到能用的 busybox：KernelSU 与 Magisk 各有一份，同一二进制
find_busybox() {
    for _b in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox busybox; do
        if command -v "$_b" >/dev/null 2>&1; then
            echo "$_b"
            return 0
        fi
    done
    return 1
}

# 用指定 DNS 解析一个域名的全部 IPv4，一行一个；失败输出空
lookup_a() {
    _bb=$(find_busybox) || return 1
    "$_bb" nslookup "$1" "$2" 2>/dev/null \
        | sed -n 's/^Address:[[:space:]]*\([0-9][0-9.]*\)$/\1/p' \
        | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'
}

# 三层取边缘 IP：解析 → 缓存 → 内置。设置全局 EDGE_IPS（空格分隔）与 EDGE_SOURCE。
resolve_edges() {
    EDGE_IPS=""
    EDGE_SOURCE=""

    for _dns in $EDGE_DNS; do
        _got=""
        for _h in $EDGE_HOSTS; do
            _got="$_got $(lookup_a "$_h" "$_dns" | tr '\n' ' ')"
        done
        _got=$(printf '%s' "$_got" | tr -s ' ' '\n' | grep -v '^$' | sort -u | tr '\n' ' ')
        # 两个 region 至少各来一个，才算一次可信的解析
        if [ "$(printf '%s' "$_got" | grep -o '198\.41\.192\.' | wc -l)" -ge 1 ] \
           && [ "$(printf '%s' "$_got" | grep -o '198\.41\.200\.' | wc -l)" -ge 1 ]; then
            EDGE_IPS="$_got"
            EDGE_SOURCE="dns:$_dns"
            printf '%s\n' "$EDGE_IPS" > "$EDGE_CACHE" 2>/dev/null || true
            return 0
        fi
    done

    if [ -s "$EDGE_CACHE" ]; then
        EDGE_IPS=$(head -1 "$EDGE_CACHE")
        EDGE_SOURCE="cache"
        return 0
    fi

    EDGE_IPS="$EDGE_BUILTIN"
    EDGE_SOURCE="builtin"
    return 0
}

# 把 EDGE_IPS 变成 --edge 参数串（每个 IP 一个参数，cloudflared 不接受逗号分隔）
edge_args() {
    _out=""
    for _ip in $EDGE_IPS; do
        _out="$_out --edge $_ip:$EDGE_PORT"
    done
    printf '%s' "$_out"
}

# ============ 模块描述（运行状态展示） ============
# 写入策略：module.prop 覆盖所有管理器；KernelSU/APatch 额外走官方 override 机制
write_description() {
    _text="$1"

    if [ -f "$MODPROP" ]; then
        _tmp="$MODPROP.tmp.$$"
        if grep -v '^description=' "$MODPROP" > "$_tmp" 2>/dev/null; then
            printf 'description=%s\n' "$_text" >> "$_tmp"
            mv -f "$_tmp" "$MODPROP"
        fi
        rm -f "$_tmp" 2>/dev/null
    fi

    if command -v ksud >/dev/null 2>&1; then
        KSU_MODULE="$MODULE_ID" ksud module config set override.description "$_text" >/dev/null 2>&1 || true
    fi
}

refresh_description() {
    if ! resolve_token_file >/dev/null 2>&1; then
        write_description "[⚠️ 未找到 token.txt] $BASE_DESC"
        return 0
    fi

    _total=$(token_count)
    if [ "$_total" -eq 0 ]; then
        write_description "[⚠️ 无有效 Token] $BASE_DESC"
        return 0
    fi

    _run=$(running_count)
    if [ "$_run" -gt 0 ]; then
        write_description "[🟢 运行中 $_run/$_total] $BASE_DESC"
    else
        write_description "[⚪ 已停止] $BASE_DESC"
    fi
}

# ============ 单实例启停 ============
start_one() {
    _idx="$1"
    _token="$2"
    _pidfile="$RUN_DIR/$_idx.pid"
    _logfile="$LOG_DIR/tunnel-$_idx.log"

    _old=$(cat "$_pidfile" 2>/dev/null)
    if [ -n "$_old" ] && kill -0 "$_old" 2>/dev/null; then
        log "  隧道 #$_idx 已在运行 (PID: $_old)"
        return 0
    fi

    # $EDGE_ARGS 故意不加引号：它是多个 --edge ip:port 参数，需要按空格拆开
    # shellcheck disable=SC2086
    HOME="$MODDIR" TMPDIR="$MODDIR" TUNNEL_EDGE_IP_VERSION=4 \
        nohup "$CFD_BIN" tunnel \
        --no-autoupdate \
        --edge-ip-version 4 \
        --loglevel "$LOG_LEVEL" \
        $EDGE_ARGS \
        run --token "$_token" \
        >> "$_logfile" 2>&1 &

    _pid=$!
    echo "$_pid" > "$_pidfile"
    renice -5 "$_pid" >/dev/null 2>&1 || true
    return 0
}

# 拉起全部隧道后统一等一次再逐个核对，不再每条各等 1 秒
verify_one() {
    _idx="$1"
    _pidfile="$RUN_DIR/$_idx.pid"
    _pid=$(cat "$_pidfile" 2>/dev/null)

    if [ -n "$_pid" ] && kill -0 "$_pid" 2>/dev/null; then
        log "  ✓ 隧道 #$_idx 已启动 (PID: $_pid)"
        return 0
    fi

    rm -f "$_pidfile"
    log "  ✗ 隧道 #$_idx 启动失败，详见 $LOG_DIR/tunnel-$_idx.log"
    return 1
}

# 停止全部有 pid 记录的隧道：先一起发 SIGTERM，再一起等，最后补 SIGKILL。
# 之前是逐条发、逐条等，N 条隧道要等 N 倍时间。
stop_all() {
    _pids=""
    for _f in "$RUN_DIR"/*.pid; do
        [ -f "$_f" ] || continue
        _idx=$(basename "$_f" .pid)
        _p=$(cat "$_f" 2>/dev/null)
        if [ -n "$_p" ] && kill -0 "$_p" 2>/dev/null; then
            kill -TERM "$_p" 2>/dev/null
            _pids="$_pids $_p"
        fi
        log "  ✓ 隧道 #$_idx 已停止"
    done

    # 最多等 5 秒
    _w=0
    while [ "$_w" -lt 25 ] && alive_any $_pids; do
        nap
        _w=$((_w + 1))
    done

    for _p in $_pids; do
        kill -0 "$_p" 2>/dev/null && kill -9 "$_p" 2>/dev/null
    done
    rm -f "$RUN_DIR"/*.pid 2>/dev/null || true
}

# 兜底清理：杀掉没有 pid 记录的残留进程。没有残留就不等，直接返回。
cleanup_orphans() {
    if pgrep -f "$PROC_PATTERN" >/dev/null 2>&1; then
        pkill -TERM -f "$PROC_PATTERN" 2>/dev/null || true
        nap
        pkill -KILL -f "$PROC_PATTERN" 2>/dev/null || true
    fi
    rm -f "$RUN_DIR"/*.pid 2>/dev/null || true
}

# ============ 命令实现 ============
cmd_start() {
    ensure_dirs

    if [ ! -w "$MODDIR" ]; then
        log "✗ 模块目录不可写: $MODDIR"
        return 1
    fi

    if [ ! -x "$CFD_BIN" ]; then
        log "✗ 找不到可执行文件: $CFD_BIN"
        return 1
    fi

    # 进程还在跑但 pid 记录已丢失（例如模块刚升级），先清理干净再启动
    if [ "$(running_count)" -eq 0 ]; then
        cleanup_orphans
    fi

    _tf=$(resolve_token_file) || {
        log "✗ 未找到 token.txt"
        log "  请编辑: $TOKEN_FILE"
        echo "disabled" > "$STATE_FILE" 2>/dev/null || true
        refresh_description
        return 1
    }

    _count=$(token_count)
    if [ "$_count" -eq 0 ]; then
        log "✗ $_tf 中没有有效 Token（每行一个，# 开头为注释）"
        echo "disabled" > "$STATE_FILE" 2>/dev/null || true
        refresh_description
        return 1
    fi

    log "Token 来源: $_tf"
    log "待启动隧道: $_count 个"

    resolve_edges
    EDGE_ARGS=$(edge_args)
    _n_edge=$(printf '%s' "$EDGE_IPS" | wc -w | tr -d ' ')
    case "$EDGE_SOURCE" in
        dns:*)   log "边缘节点   : $_n_edge 个（实时解析 ${EDGE_SOURCE#dns:}）" ;;
        cache)   log "边缘节点   : $_n_edge 个（解析失败，用上次缓存）" ;;
        builtin) log "边缘节点   : $_n_edge 个（解析失败且无缓存，用内置列表）" ;;
    esac
    printf '%s\n' "$EDGE_SOURCE" > "$RUN_DIR/edge.source" 2>/dev/null || true

    _list="$RUN_DIR/tokens.list"
    list_tokens "$_tf" > "$_list"

    # 先全部拉起，再短暂观察：进程都还活着就立刻放行，
    # 只有有进程立即退出时才多等几个周期确认，不再无条件等满 1 秒
    _i=0
    _started=""
    while IFS= read -r _tk; do
        _i=$((_i + 1))
        start_one "$_i" "$_tk"
        _started="$_started $(cat "$RUN_DIR/$_i.pid" 2>/dev/null)"
    done < "$_list"
    rm -f "$_list"

    _w=0
    while [ "$_w" -lt 5 ]; do
        nap
        _w=$((_w + 1))
        _dead=0
        for _p in $_started; do
            kill -0 "$_p" 2>/dev/null || _dead=1
        done
        # 全活着：再给 1 个周期让极快的失败暴露出来，然后放行
        if [ "$_dead" -eq 0 ] && [ "$_w" -ge 2 ]; then
            break
        fi
    done

    _ok=0
    _j=1
    while [ "$_j" -le "$_i" ]; do
        verify_one "$_j" && _ok=$((_ok + 1))
        _j=$((_j + 1))
    done

    if [ "$_ok" -gt 0 ]; then
        echo "enabled" > "$STATE_FILE" 2>/dev/null || true
        log "启动完成: $_ok/$_count 个隧道运行中"
    else
        echo "disabled" > "$STATE_FILE" 2>/dev/null || true
        log "启动失败: 0/$_count"
    fi

    refresh_description
    [ "$_ok" -gt 0 ]
}

cmd_stop() {
    ensure_dirs
    log "停止全部隧道..."

    stop_all
    cleanup_orphans

    echo "disabled" > "$STATE_FILE" 2>/dev/null || true
    log "已全部停止"
    refresh_description
    return 0
}

cmd_status() {
    _tf=$(resolve_token_file 2>/dev/null)
    _total=$(token_count)
    _run=$(running_count)

    log "模块目录   : $MODDIR"
    log "Token 文件 : ${_tf:-未找到}"
    log "已配置隧道 : $_total"
    log "运行中隧道 : $_run"
    log "开机自启   : $(cat "$STATE_FILE" 2>/dev/null || echo unknown)"
    log "边缘来源   : $(cat "$RUN_DIR/edge.source" 2>/dev/null || echo '尚未启动')"

    for _f in "$RUN_DIR"/*.pid; do
        [ -f "$_f" ] || continue
        _idx=$(basename "$_f" .pid)
        _p=$(cat "$_f" 2>/dev/null)
        if [ -n "$_p" ] && kill -0 "$_p" 2>/dev/null; then
            log "  #$_idx 运行中 (PID: $_p)"
        fi
    done

    log "日志目录   : $LOG_DIR"
}

cmd_toggle() {
    ensure_dirs

    if [ "$(running_count)" -gt 0 ]; then
        log "当前状态: 运行中，执行停止"
        cmd_stop
    else
        log "当前状态: 已停止，执行启动"
        cmd_start
    fi
}

cmd_boot() {
    if [ "$(cat "$STATE_FILE" 2>/dev/null)" = "enabled" ]; then
        cmd_start
    else
        refresh_description
    fi
}

# ============ 入口 ============
case "$1" in
    start)   cmd_start ;;
    stop)    cmd_stop ;;
    restart) cmd_stop; cmd_start ;;
    toggle)  cmd_toggle ;;
    status)  cmd_status ;;
    boot)    cmd_boot ;;
    refresh) refresh_description ;;
    *)
        echo "用法: $0 {start|stop|restart|toggle|status|boot|refresh}"
        exit 1
        ;;
esac
