#!/system/bin/sh
# service.sh - Magisk late_start service 阶段执行
# 按上次的开关状态恢复隧道，不改变用户的选择

MODDIR=${0%/*}

# 等待网络接口就绪（最多 30 秒）
_i=0
while [ "$_i" -lt 30 ]; do
    if [ -f /sys/class/net/wlan0/operstate ] || [ -f /sys/class/net/rmnet_data0/operstate ]; then
        break
    fi
    sleep 1
    _i=$((_i + 1))
done

mkdir -p "$MODDIR/logs" 2>/dev/null || true
sh "$MODDIR/cloudflared.sh" boot >> "$MODDIR/logs/service.log" 2>&1
