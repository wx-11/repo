#!/system/bin/sh
# uninstall.sh - 模块卸载时执行
# 保证移除模块后不会留下仍在运行的隧道进程

MODDIR=${0%/*}

for _f in "$MODDIR"/run/*.pid; do
    [ -f "$_f" ] || continue
    _p=$(cat "$_f" 2>/dev/null)
    [ -n "$_p" ] && kill -TERM "$_p" 2>/dev/null
done

sleep 1

pkill -KILL -f "$MODDIR/system/bin/cloudflared tunnel" 2>/dev/null || true
pkill -KILL -f "$MODDIR/system/bin/cloudflared proxy-dns" 2>/dev/null || true

rm -rf "$MODDIR/run" "$MODDIR/logs" 2>/dev/null || true

exit 0
