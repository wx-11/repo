# Cloudflare Tunnel for Android

把 Cloudflare Tunnel 做成一个"开关式"的 Android 模块：一个按钮启动，再点一次停止，支持同时运行多条隧道。

## 特性

- **一个按钮控制启停** - 模块卡片上的「操作」按钮，点击一次启动，再点一次停止
- **状态实时可见** - 模块描述最前面的方括号里直接显示运行状态与隧道数量
- **WebUI 控制面板** - 看实时连接的边缘节点、看日志、改 Token、一键启停
- **多隧道并行** - `token.txt` 一行一个 Token，多行就会同时建立多条隧道
- **配置自包含** - Token、状态、日志全部存放在模块目录，不污染内部存储
- **开机自动恢复** - 重启后按上次的开关状态自动拉起，无需重新点击
- **在线更新** - 内置 `updateJson`，模块管理器可直接检测并安装新版本
- **ARM / ARM64 双架构** - 使用 Termux 官方编译的 cloudflared 二进制

## 环境要求

- Android 设备已 Root
- 模块管理器：**KernelSU / APatch / MMRL**（支持操作按钮）
- 架构：ARMv7 或 ARM64

> **Magisk 用户请注意**：Magisk 官方管理器没有"操作按钮"入口。
> 在 Magisk 上模块描述依然会正常显示运行状态，但启动/停止需要手动执行：
> ```bash
> su -c sh /data/adb/modules/cloudflared4android/cloudflared.sh toggle
> ```
> 也可以安装 [MMRL](https://github.com/MMRLApp/MMRL) 或
> [KsuWebUI](https://github.com/5ec1cff/KsuWebUIStandalone) 来获得按钮。

## 安装

1. 从分发仓库下载最新的
   [cloudflared4android.zip](https://raw.githubusercontent.com/wx-11/repo/main/cloudflared4android/cloudflared4android.zip)
2. 在模块管理器中安装
3. 打开模块的 **WebUI**，在「token.txt」里粘贴 Token（一行一个），点「保存 Token」
4. 点「启动隧道」，或者点模块卡片上的「操作」按钮

不想用 WebUI 的话，直接编辑模块目录下的 `token.txt` 也行，见下一节。

## 配置 Token

配置文件位于模块目录：

```
/data/adb/modules/cloudflared4android/token.txt
```

格式：**一行一个 Token**，空行和 `#` 开头的注释行会被忽略。

```
# 隧道 A
eyJhIjoiYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoifQ...

# 隧道 B
eyJhIjoiYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoifQ...
```

Token 获取：<https://one.dash.cloudflare.com> → Networks → Tunnels → 创建隧道 → 复制 Token。

编辑需要 root 权限，可以直接用模块管理器自带的文件编辑器，或：

```bash
su -c 'vi /data/adb/modules/cloudflared4android/token.txt'
```

修改 `token.txt` 后需要重启隧道使其生效（WebUI 里保存后会提示并给出重启按钮）。
模块升级时 `token.txt` 与开关状态会自动保留。

## 运行状态

模块描述会实时反映状态，无需点进去查看：

| 描述内容 | 含义 |
| --- | --- |
| `[🟢 运行中 2/3] …` | 3 条隧道中有 2 条在运行 |
| `[⚪ 已停止] …` | 全部已停止 |
| `[⚠️ 未找到 token.txt] …` | 缺少配置文件 |
| `[⚠️ 无有效 Token] …` | 文件存在但没有可用 Token |

状态放在描述最前面的方括号里，模块列表里一眼就能扫到，不用展开。

## WebUI 控制面板

在 KernelSU / APatch / MMRL 里点开模块的「WebUI」，不用敲命令就能：

- 看当前状态，以及每条隧道**实时接到了哪些边缘节点**（如 `hkg01 quic`），
  运行中每 3 秒刷新一次
- 看每条隧道的日志尾部，警告与错误高亮
- 在文本框里增删 Token，保存即写入 `token.txt`
- 一键启动 / 停止

保存 Token **不会**自动重启正在运行的隧道——页面会提示「重启后生效」，
并出现「重启隧道」按钮，由你决定何时重启。写入经 base64 中转，
内容里含任何字符都不会破坏命令。

页面上「连接」一栏显示每条隧道实时接到的边缘节点。cloudflared 默认开 4 条连接，
所以每行最多 4 个槽位；虚线空位表示这条连接还没建立。协议几乎总是 quic，
只有非 quic（如 http2）时才会标出来。

> 页面会把 Token 明文显示在编辑框里——它本来就是给你编辑用的，
> 录屏或截图时留意一下。

**前提**：KernelSU / APatch 原生支持 WebUI；原版 Magisk 的管理器没有这个入口，
需要安装 [MMRL](https://github.com/MMRLApp/MMRL) 或
[KsuWebUI Standalone](https://github.com/5ec1cff/KsuWebUIStandalone)。

页面是单文件静态页，**不起服务、不占端口**：管理器用 WebView 渲染它，
再通过 JS 桥接以 root 身份执行 shell 命令来读写模块目录。
它不加载任何外部资源——这点是刻意的，页面拿着 root shell，不能引入远程内容。

## 命令行

```bash
# 启停切换（按钮调用的就是它）
su -c sh /data/adb/modules/cloudflared4android/cloudflared.sh toggle

# 启动 / 停止 / 重启
su -c sh /data/adb/modules/cloudflared4android/cloudflared.sh start
su -c sh /data/adb/modules/cloudflared4android/cloudflared.sh stop
su -c sh /data/adb/modules/cloudflared4android/cloudflared.sh restart

# 查看状态
su -c sh /data/adb/modules/cloudflared4android/cloudflared.sh status
```

## 文件结构

所有数据都在模块目录内，卸载模块时会一并清除：

```
/data/adb/modules/cloudflared4android/
├── system/bin/cloudflared    # cloudflared 主程序
├── token.txt                 # Token 列表（用户数据，升级时保留）
├── state                     # 开/关状态（升级时保留）
├── action.sh                 # 「操作」按钮入口
├── cloudflared.sh            # 启停与状态控制逻辑
├── service.sh                # 开机按上次状态恢复
├── uninstall.sh              # 卸载时停止所有隧道
├── webroot/index.html        # WebUI 控制面板
├── run/<n>.pid               # 各隧道进程号
└── logs/tunnel-<n>.log       # 各隧道日志
```

## 在线更新

模块使用 Magisk / KernelSU 通用的 `updateJson` 机制：

1. `module.prop` 中的 `updateJson` 指向一个公开可访问的 JSON
2. 模块管理器读取 JSON，比较其中的 `versionCode` 与本地值
3. 远端更大时提示更新，`zipUrl` 即安装包下载地址

JSON 格式：

```json
{
  "version": "2026.9.1",
  "versionCode": 20260914,
  "zipUrl": "https://raw.githubusercontent.com/wx-11/repo/main/cloudflared4android/cloudflared4android.zip",
  "changelog": "https://github.com/wx-11/repo/commits/main/cloudflared4android"
}
```

模块包用固定文件名 `cloudflared4android.zip`，下载链接永远不变；
分发仓库不用 Release，每次发布是一次普通提交，历史可在 `changelog` 链接里看。

`updateJson` 的地址由构建流程在打包时自动写入，取值来自仓库变量 `PUBLIC_REPO`（见下）。
未配置该变量时，打出的包不含 `updateJson`，模块管理器就不会提示更新。

### 分发仓库的目录结构

分发仓库不只放这一个模块，所以产物**按模块 ID 隔离**，
以后加入其它模块或 iOS 越狱包时互不干扰：

```
wx-11/repo/
├── cloudflared4android/
│   ├── cloudflared4android.zip   # 模块包，固定文件名
│   └── update.json               # 本模块的更新清单
└── (以后) 其它模块/<模块-id>/…
```

本模块的更新链接：

```
https://raw.githubusercontent.com/wx-11/repo/main/cloudflared4android/update.json
```

`<模块-id>` 取自 `module.prop` 的 `id=`，新增模块时无需改构建流程。

### 从私有仓库发布到公共仓库

如果你把开发放在私有仓库、把发布放在公共仓库，构建流程已内置支持：

1. 新建一个**公共**仓库用于分发，本文按 `wx-11/repo` 命名
   （与本 README 的下载链接保持一致；换名字就要同步改 README）
2. 生成一个**细粒度 Personal Access Token**，只授权该公共仓库的
   `Contents: Read and write` 权限
3. 在私有仓库的 `Settings → Secrets and variables → Actions` 中添加：
   - Secret：`PUBLIC_REPO_TOKEN` = 上一步的 Token
   - Variable：`PUBLIC_REPO` = 公共仓库全名，即 `wx-11/repo`
4. 之后每次打包会自动：
   - 把模块包以固定文件名提交到 `cloudflared4android/cloudflared4android.zip`
   - 写入 `cloudflared4android/update.json`
   - 把 `updateJson` 地址注入到包内的 `module.prop`

> **重要**：跨仓库推送必须用 PAT，不能用默认的 `GITHUB_TOKEN`。
> 详情见下方「为什么不能用 GITHUB_TOKEN」。

## 故障排查

日志在模块目录内，读取需要 root：

```bash
# 查看隧道日志（<n> 为第几个 Token，从 1 开始）
su -c 'tail -f /data/adb/modules/cloudflared4android/logs/tunnel-1.log'

# 查看开机启动日志
su -c 'cat /data/adb/modules/cloudflared4android/logs/service.log'

# 检查进程
su -c 'ps -A | grep cloudflared'

# 常见原因
# - Token 失效或隧道已被删除 → 到 Cloudflare 后台重新获取
# - 网络未就绪 → 等待网络恢复后重新点击按钮
```

### 隧道连不上，日志里全是 `lame referral`

```
lookup _v2-origintunneld._tcp.argotunnel.com on 1.1.1.1:53: lame referral
```

这是 **DNS 查询被拦截，不是 Token 的问题**。Token 有问题时 cloudflared 会明确说
invalid token，而这里「隧道启动」已经出现，说明 Token 读取正常，卡在下一步：
查 SRV 记录找 Cloudflare 边缘节点。

**先看你是不是开着 VPN。** 实测同一台设备、同一个 Wi-Fi：开着 VPN（日志里
`ICMP proxy will use ... in zone tun0`）就报这个错，关掉 VPN（`zone wlan0`）
立刻正常。多数 VPN 会接管 DNS，把 SRV 查询应答成一个只有委派、没有答案的空壳，
Go 的 DNS 库把这种响应叫 `lame referral`。

```
# 怎么判断：看日志里这一行
ICMP proxy will use 192.168.1.74 in zone wlan0   ← 直连 Wi-Fi，正常
ICMP proxy will use 198.19.0.1 in zone tun0      ← 走 VPN，会被拦
```

**解法**：关掉 VPN 再重启隧道，或者把 cloudflared 加入 VPN 的分流白名单。
不开 VPN 的话，cloudflared 自带的 `1.1.1.1:53` 在国内 Wi-Fi 上是通的；
53 端口被拦时它还会自动改走 `1.1.1.1:853`（DNS over TLS）再试一次。

**模块层面为什么不能替你解决**：cloudflared 的边缘发现直接调用 Go 标准库的
`net.LookupSRV`，不接受任何自定义解析器——`--dns-resolver-addrs` 那个开关管的是
别的路径，对这一步无效（本模块曾经实现过 `dns.txt` 换 DNS，实测环境变量被读到、
但查询仍走 `1.1.1.1`，已撤掉）。曾经的另一条路 `cloudflared proxy-dns`（本机起
DoH 代理）也在 2026.2.0 被官方移除，打包的 2026.9.1 不再支持。
所以这件事只能在网络层解决。

> **关于旧版（2.x）**：旧版靠 iptables 把全机 53 端口重定向到本地 DoH 代理，
> 但规则链第一条是 `-m owner --uid-owner 0 -j RETURN`——放行 root 的流量。
> cloudflared 恰好以 root 运行，隧道自己不受重定向影响，照样直连 `1.1.1.1:53`；
> 而且它依赖的 `proxy-dns` 现在也没了。旧版在开 VPN 时会撞上完全一样的错误。

### 为什么不能用 GITHUB_TOKEN

GitHub Actions 的默认令牌 `GITHUB_TOKEN` 有一个硬性限制：

> 除 `workflow_dispatch` 和 `repository_dispatch` 外，
> 由 `GITHUB_TOKEN` 触发的事件不会创建任何 workflow 运行。

也就是说，用 `GITHUB_TOKEN` 推送代码，**不会**触发目标仓库的工作流。
这也是本仓库串联"同步二进制 → 打包"时用 `repository_dispatch` 而不是靠 `push`
的原因——它正好是那两个例外之一，同步工作流用默认令牌就能拉起打包。
但跨仓库写入不在例外里，因此发布到公共仓库必须使用 Personal Access Token、
GitHub App Token 或 Deploy Key 这类独立凭据。

## 参考链接

### 本项目相关的上游

- [Cloudflare Tunnel 控制台](https://one.dash.cloudflare.com) - 创建隧道、获取 Token
- [Cloudflare One 连接文档](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/)
- [cloudflared 官方仓库](https://github.com/cloudflare/cloudflared) - 版本号与本模块同步
- [Cloudflare Tunnel 故障排查](https://developers.cloudflare.com/tunnel/troubleshooting/) -
  官方列出的常见连接问题，含 DNS / SRV 解析失败的排查步骤
- [cloudflared 边缘发现源码](https://github.com/cloudflare/cloudflared/blob/master/edgediscovery/allregions/discovery.go) -
  SRV 查询直接调 `net.LookupSRV`，失败后兜底 `1.1.1.1:853` DoT；不接受自定义解析器
- [cloudflared 移除 proxy-dns 的公告](https://developers.cloudflare.com/changelog/2025-11-11-cloudflared-proxy-dns/) -
  自 2026.2.0 起 `proxy-dns` 子命令被移除，本模块曾依赖它做 DoH 兜底，已撤
- [Go 标准库 `net` 包源码](https://github.com/golang/go/blob/master/src/net/dnsclient_unix.go) -
  `lame referral` 这条错误信息的出处；它表示 DNS 响应只含委派信息、没有答案

### 边缘节点解析失败（lame referral）相关

- [Cloudflare 1.1.1.1 设置指南](https://developers.cloudflare.com/1.1.1.1/setting-up-1.1.1.1/) -
  cloudflared 报错时自己给出的建议链接
- [golang/go#27546](https://github.com/golang/go/issues/27546) - cloudflared 报错里引用的
  Go issue，关于解析器返回压缩 SRV 记录导致查询失败
- [cloudflared 在 Docker 中 DNS 解析异常的排查](https://www.cnblogs.com/funkyd/p/21409481) -
  中文实战记录，同样是边缘发现的 SRV 查询失败，思路可对照
- [Android 上 cloudflared SRV 查询失败的讨论](https://agents.stackoverflow.com/questions/d0476771-32f5-458d-91d4-37d0ebdff866) -
  非 root 环境下无解；本模块有 root，可以直接换 DNS

### 模块框架

- [Magisk](https://github.com/topjohnwu/Magisk) - 模块系统与安装器
- [Magisk `scripts/module_installer.sh`](https://github.com/topjohnwu/Magisk/blob/master/scripts/module_installer.sh) -
  `META-INF/com/google/android/update-binary` 的来源
- [Magisk `scripts/util_functions.sh`](https://github.com/topjohnwu/Magisk/blob/master/scripts/util_functions.sh) -
  `install_module` / `set_perm` / `ui_print` 等安装期函数的定义
- [Magisk 开发者文档](https://magisk.readthedocs.io/) - 模块格式与 `module.prop` 字段说明
- [KernelSU](https://github.com/tiann/KernelSU) - 操作按钮与模块描述覆盖机制
- [KernelSU 模块文档](https://kernelsu.org/guide/module.html) - `action.sh` 按钮与脚本阶段
- [KernelSU 模块配置](https://kernelsu.org/guide/module-config.html) - `override.description` 描述覆盖
- [KernelSU 模块 WebUI](https://kernelsu.org/guide/module-webui.html) - `webroot/` 与 JS API
- [KernelSU JS API 类型定义](https://github.com/tiann/KernelSU/blob/main/js/index.d.ts) -
  `exec` / `spawn` / `toast` 等接口的签名，本模块 WebUI 只用了 `exec` 与 `toast`
- [APatch](https://github.com/bmax121/APatch) - 同样支持 `action.sh`
- [MMRL](https://github.com/MMRLApp/MMRL) - 给 Magisk 提供操作按钮与 WebUI
- [KsuWebUI Standalone](https://github.com/5ec1cff/KsuWebUIStandalone) - 独立的 WebUI 宿主

### 二进制来源

- [Termux 软件包索引](https://packages.termux.dev/apt/termux-main/) - 本模块二进制的下载源
- [termux-packages](https://github.com/termux/termux-packages) - Termux 打包脚本

### 设计参考

- [WSTunnel4Magisk](https://github.com/WeiguangTWK/wstunnel4magisk) -
  多实例 + `action.sh` 一键启停的实现参考

## 开源协议

GPL v3.0
